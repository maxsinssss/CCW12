/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author VARTIK
 */
@WebService(serviceName = "convert")
public class convert {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "FtoC")
    public String FtoC(@WebParam(name = "a") double a) {
        //TODO write your implementation code here:
        return "The Farenheit temp "+ a +" in celcius is "+ ((a-32)*5/9);
    }

    
}
